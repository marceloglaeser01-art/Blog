
  # Apple-esque Blog Design

  This is a code bundle for Apple-esque Blog Design. The original project is available at https://www.figma.com/design/CvzUB37CxJJLsrq332PJLK/Apple-esque-Blog-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  